test addon readme
